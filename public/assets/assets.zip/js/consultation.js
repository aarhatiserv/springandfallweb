// Display please wait when click tab of country and courses and career
$(document).ready(function() {
    $('.college').html("Please wait...");
    $('.college').prop("disabled", true);
});

// refresh when click course tab related with session of home, flag click
function refresh() {
    window.location.href="consultation";
}



// apply for collages
function applyForCollegeInConsultation(id) {

    let formData = new FormData();
    formData.append('id', id);
    $.ajax({
      url: "/api/applyForCollegeInConsultation",
      method: "POST",
      data: formData,
      processData: false,
      contentType: false,
      beforeSend: function () {
        $("#apply").val("Please wait");
        $("#apply").prop("disabled", true);
      },
      success: function (data) {
        $("#apply").prop("disabled", false);
        var res = JSON.parse(data);
        if (res.status === 1) {
          swal("Thank you!", res.message, "success");
          // window.location.reload();
        } else if (res.status === 2) {
          swal("Opps.!!", res.message, "error");
        } else {
          swal("Opps.!!", "Something went wrong.!!", "error");
        }
      },
    });
  }
  // apply for collages code ends here

// getCountry in consultation
function getCollegeInConsultation(country) {

    $('.college').html("Please wait...");
    $('.college').prop("disabled", true);

    $.ajax({
        url: '/api/college/' + country,
        type: 'GET',
        success: function(res) {
            let collegeData = JSON.parse(res);
            let dt = [];
            console.log('res', collegeData);
            if (collegeData.status !== undefined) {

                if (collegeData.data.length == 0) {
                    $('.college').html("No Record Found");
                    $('.college').prop("disabled", false);
                } else {
                    collegeData.data.map((item) => (
                        dt.push(
                            ` <li class="media my-4 bg-light">
                                <img class="p-3 image" style="max-width: 20%; height: 167px;" src="uploads/CollegesImage/` +
                            item.image + `" class="mr-3" alt="..."
                                    title="hrl" width="" height="" />
                                <div class="media-body py-3">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <p class="mt-0 mb-1 media-heading pb-2 h5_2_P">` + item.names + `</p>
                                            <p>` + item.country + ` </p>
                                            <p>` + item.courses + ` </p>
                                        </div>
                                        <div class="col-md-4 d-flex justify-content-end align-items-center ">
                                            <div class="apply px-5">
                                                <p class="h5_2_P_Days">5 Days to go</p>
                                                <button class="btn applyNow" onclick="applyForCollegeInConsultation(` + item.id +`)">Apply now</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>`
                        )
                    ));
                    // $("#listColleges").html(dt);
                    $('.college').html(dt);
                    $('.college').prop("disabled", false);
                }
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            var errorMsg = 'Ajax request failed: ' + xhr.responseText;
            console.log(`error`, err);
            $('.ajaxError').html("Countries");
            $('.ajaxError').prop("disabled", false);
            if (err) {
                swal("Oh noes!", "The AJAX request failed!", "error");
            }
        }
    });

}

var country = "";
var courses = "";

// getCollegeWithCountry in consultation
function getCollegeWithCountry(country) {
    if (country != "") {
        this.country = country;
        getCollegeWithCountryAndCoursesInConsultation();
    } else {
        console.log("Please Select Any Country");
    }
}

// getCollegeWithCourse in consultation

function getCollegeWithCourse(courses) {
    if (courses != "") {
        this.courses = courses;
        getCollegeWithCountryAndCoursesInConsultation();
    } else {
        console.log("Please Select Any Course");
    }

}

// getCollegeWithCourse in consultation And // getCollegeWithCountry in consultation

function getCollegeWithCountryAndCoursesInConsultation() {

    $('.collegeWithCourse').html("Please wait...");
    $('.collegeWithCourse').prop("disabled", true);

    $.ajax({
        url: '/api2/college/' + country + '/' + courses,
        type: 'GET',
        success: function(res) {
            let collegeData = JSON.parse(res);
            let dt = [];
            console.log('res', collegeData);
            if (collegeData.status !== undefined) {

                if (collegeData.data.length == 0) {
                    $('.collegeWithCourse').html("No Record Found");
                    $('.collegeWithCourse').prop("disabled", false);
                } else {
                    collegeData.data.map((item) => (
                        dt.push(
                            ` <li class="media my-4 bg-light">
                                <img class="p-3 image" style="max-width: 20%; height: 167px;" src="uploads/CollegesImage/` +
                            item.image + `" class="mr-3" height="" width="" alt="..." title="hrl" />
                                <div class="media-body py-3">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <p class="mt-0 mb-1 media-heading pb-2 h5_2_P">` + item.names + `</p>
                                            <p>` + item.country + ` </p>
                                            <p>` + item.courses + ` </p>
                                        </div>
                                        <div class="col-md-4 d-flex justify-content-end align-items-center ">
                                            <div class="apply px-5">
                                                <p class="h5_2_P_Days">5 Days to go</p>
                                                <button class="btn applyNow" onclick="applyForCollegeInConsultation(` + item.id +`)">Apply now</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>`
                        )
                    ));
                    // $("#listColleges").html(dt);
                    $('.collegeWithCourse').html(dt);
                    $('.collegeWithCourse').prop("disabled", false);
                }
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            var errorMsg = 'Ajax request failed: ' + xhr.responseText;
            console.log(`error`, err);
            $('.ajaxError').html("Countries");
            $('.ajaxError').prop("disabled", false);
            if (err) {
                swal("Oh noes!", "The AJAX request failed!", "error");
            }
        }
    });
    
}